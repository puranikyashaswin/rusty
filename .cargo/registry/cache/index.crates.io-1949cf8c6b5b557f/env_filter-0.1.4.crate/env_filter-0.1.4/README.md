# env_filter

[![crates.io](https://img.shields.io/crates/v/env_filter.svg)](https://crates.io/crates/env_filter)
[![Documentation](https://docs.rs/env_filter/badge.svg)](https://docs.rs/env_filter)

> Filter log events using environment variables
