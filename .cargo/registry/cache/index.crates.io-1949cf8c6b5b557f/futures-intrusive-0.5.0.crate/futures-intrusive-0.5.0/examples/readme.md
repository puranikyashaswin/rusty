# Examples

This folder contains examples for the usage of this library.

Examples can be started in the following fashion:
```
cargo run --example name_of_example
```